# Learn Sign Dictionary

This is a full React app to search and learn global sign languages. Includes Firebase, Paystack, and AI support.

## Features
- Secure login (Firebase)
- Payment plans (Paystack + Google Pay)
- Media uploads (admin-only)
- Multilingual TTS + voice search
- AI-assisted query to find matching signs

## How to Run
1. Add your Firebase + Paystack config keys
2. Run `npm install`
3. Start with `npm run dev` or build & deploy

## Deployment
- Use [Vercel](https://vercel.com) for fastest deploy
- Or use Firebase Hosting

Built by Chat.io © 2025