# Learn Sign Dictionary

This project was generated for deployment with Vercel.

To run locally:
```
npm install
npm run dev
```